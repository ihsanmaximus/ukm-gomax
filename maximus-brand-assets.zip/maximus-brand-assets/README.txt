MAXIMUS BRAND ASSETS

Included files:
- assets/images/og/maximus-og.jpg  (1200 x 630, Open Graph image)
- favicon-32.png
- favicon-16.png
- favicon-512.png
- apple-touch-icon.png (180 x 180)
- favicon.ico

favicon.svg has already been added to the GitHub repository root.
The index.html already contains the Open Graph/Twitter metadata and now references favicon.svg,
favicon-32.png, and apple-touch-icon.png.

INSTALL (run from the project root in VS Codroid terminal):
1. Extract this ZIP into the project root, preserving folders.
2. Run:
   git add assets/images/og/maximus-og.jpg favicon-32.png favicon-16.png favicon-512.png apple-touch-icon.png favicon.ico
   git commit -m "Add Maximus OG image and favicon assets"
   git push origin main

Then wait for Vercel deployment to finish. Re-scrape the page in Facebook Sharing Debugger
or refresh the WhatsApp link preview if an old preview is cached.
